#This script shows an example of finding optimal FISHR parameters
#using GERMLINE2 & parameter_finder2.4 on a small (n=8k, #Snps=1185, cM=16)
#simulated SNP dataset

#set wd - obviously, change /path/to/directory below
setwd("/path/to/directory/FISHR2")





##############################
# SOME CRUCIAL ISSUES RE FORMATING DATA & USING PHASING DATA
#Please read

#Several useful utilities & programs for formatting data correctly are found at the following  sites:

#http://faculty.washington.edu/browning/beagle_utilities/utilities.html as these utilities:
#beagle2vcf.jar
#vcf2beagle.jar

#http://faculty.washington.edu/browning/beagle/beagle.html has the beagle phase software
#b4.r1058.jar - note, you may download a newer phasing software with a different name

#http://www.cs.columbia.edu/~gusev/germline/ has these utilities:
#ped_to_bgl

#some utilities we have written to help  format data:
#gap - formats from SHAPEIT2 to data expected by GERMLINE
#FormatPed2 - converts from BGL output phased PED file to the phased PED file required by GERMLINE

#In particular, please note that GERMLINE2 (and FISHR) require that SNP data is in
#a PHASED PED file format. I.e.,
# A/C C/T T/A G/G G/A means that ACTGG is one estimated phase and CTAGA is the other

# ***IMPORTANT***: If you use PLINK in any way once your data is in a phased ped file, your phase
#will be lost!! So do all PLINK data cleaning first, then phase, then transform your data
#to phased ped file format, then use GERMLINE2/FISHR. Never use PLINK on a phased ped file
#unless you want to lose phase!!

#Also note that the *map files you use must have a cM distance in the 3rd column for GERMLINE2/PLINK/BEAGLE to work properly

#NOTE: this is just how a unix hack recoded their data and is here for your benefit
#There are probably much better ways to accomplish the below!
##############################







##############
#1a) Phase using SHAPEIT on PLINK BED format files and convert to phased PED file
system("shapeit.v2.r727.linux.x64 --input-bed Testplink01.bed Testplink01.bim Testplink01.fam -M hapmap.genmap15.txt --thread 20 --output-max Test.SI.haps.gz Test.SI.sample")

#gunzip the output
system("gunzip Test.SI.haps.gz")

#Use one of our utility programs to easily convert SHAPEIT output to what GERMLINE wants
system("gap -haps2ped -file Test.SI -code01 -out Test.SI")

#unfortunately, gap introduces a newline at the end of the file which will throw up a "stream is not good" warning in GERMLINE. This fixes it.
system("perl -pi -e 'chomp if eof' Test.SI.ped")

#cp the map file to right place
system("cp TestplinkACTG.map Test.SI.map")

#run GERMLINE to identify regions that are almost certainly IBD, at least in the middle
system("./GERMLINE2 -pedfile Test.8k.ped -mapfile Test.8k.map -outfile Test.SI -bin_out -err_hom 0 -err_het 0 -reduced -bits 100 -min_m 8 -w_extend")


###############






##############
#1b) Phased using BEAGLE and convert to phased PED file

#change allele coding to A/C/T/G rather than 1/2 for beagle to work
#Note: in our simulated data, all SNPs are A/C
system("plink2 --noweb --bfile Testplink01 --alleleACGT --recode --out TestplinkACTG")

#convert ped file to bgl format
system("ped_to_bgl TestplinkACTG.ped TestplinkACTG.map > Test.bgl2")

#below just to put an "I" in first entry rather than "#"!
system("sed 's/#/I/' Test.bgl2 > Test.bgl ")

#make marker file expected by utility & convert bgl format to VCF format
mrk <- read.table("TestplinkACTG.bim",header=FALSE)
system("plink2 --noweb --file TestplinkACTG --make-bed --out TestplinkACTG")    
marker.file <- mrk[,c(2,4,5,6)] #select columns to create VCF file
write.table(marker.file,"Test.mkr",row.names=FALSE,col.names=FALSE,quote=FALSE)

# http://faculty.washington.edu/browning/beagle_utilities/utilities.html#beagle2vcf
system("java -jar beagle2vcf.jar 15 Test.mkr Test.bgl -9 > Test.vcf")
#says we're doing this on chromosome 15 and -9 is missing data
#vcf file also should be phased, but double check it

#Phase the data with beagle4 - takes e.g., ~10 mins for 1000 people, 1185 markers
#https://faculty.washington.edu/browning/beagle/b4_0.html
system("java -Xmx4000m -jar beagle.r1399.jar gt=Test.vcf  usephase=false ibd=false burnin-its=5 overlap=75 window=10000  out=Test.phased > Test.phased.log")



#convert vcf to BGL file
system("gunzip -c Test.phased.vcf.gz | java -jar vcf2beagle.jar -9 Test")

#convert BGL to PED file
#system("gunzip -c Test.phased.bgl.gz | java -jar beagle2linkage.jar Test")
#https://faculty.washington.edu/browning/beagle_utilities/utilities.html#beagle2linkage
system("gunzip -c Test.bgl.gz | java -jar beagle2linkage.jar Test")




#The ped file output by beagle isn't in the actual format required by GERMLINE (e.g., 6 columns before genetic data). We wrote a utility to do this, FormatPed2.
#get correct PED file format expected by GERMLINE
system("java FormatPed2 Test.ped")
system("cp Test.ped.F Test2.ped")
system("cp TestplinkACTG.map Test2.map")

#at last, Test.ped and Test.map are computationally phased PED files. Do not use PLINK on them!

###############









###############
#2) RUN GERMLINE FOR FINDING OPTIMAL THRESHOLDS

#Note again: the PED file must be phased for this to work

#With only 1k people, Beagle/SHAPEIT do a poor job phasing and phase errors will too often cause false negative IBD segments. We will therefore read in different data than generated above - this is data phased with 8k individuals using SHAPEIT and is much higher quality

#run GERMLINE to identify regions that are almost certainly IBD, at least in the middle
#If you get a library missing error, Navigate to the Germline2 folder and compile the program by issuing the make command.
system("./GERMLINE2 -pedfile Test.8k.ped -mapfile Test.8k.map -outfile Test.8k -bin_out -err_hom 0 -err_het 0 -reduced -bits 50 -min_m 6 -w_extend")

#-pedfile - a PHASED pedfile. Note, you must use the
#-mapfile - a map file with cM distances in 3rd column
#-bin_out - a compressed output necessary for being read by gl.parameter.finder & FISHR
#-err_hom 0 - allow 0 mismatching homozygous markers
#-err_het 0 - allow 0 mismatching heterozygous markers
#-reduced - a flag telling GERMLINE to reduce the columns of the output; necessary for being read by gl.parameter.finder & FISHR
#-bits 50 - the # SNPs in each fixed window that GERMLINE uses for initial matches
#-min_m - minimum length in cM for match to be output; here 6
#-w_extend extend match beyond the "bits" window until the first opposite homozygote (OH) occurs.
#-h_extend - tells GERMLINE to use phase information as well as just opposite homozygosity in determining the SH length. It is important NOT to use this option when running GERMLINE to find optimal parameters. This is because using phase information will bias the detected SHs to have fewer phase errors than randomly chosen truly IBD segments, and will make our sensitivity & specificity values based on the chosen thresholds below appear better than they really would be in real circumstances. Although it's true that OHs also cause IEs, they are a large minority of IEs, most of which are caused by phase & SNP errors.

#less Test.log
#you should have identified 131098 IBD segments; almost all of these are truly IBD, even if possibly over-extended.
###############




###############
#3) GL.PARAMTER.FINDER TO FIND PIE & MA THRESHOLDS TO USE
#If it gives a library missing error, compile the program by navigating into the folder Parameter_finder2.4 and type make to invoke the makefile. Replace the new executable with the old one.

system("./parameter_finder2.4 -bmatch Test.8k.bmatch -bsid Test.8k.bsid -bmid Test.8k.bmid -ped-file Test.8k.ped -window 50 -cut-value 0.5 -reduced 500 8 -output-type Error1 -log-file Test.8k.WellPhasedLOG | gzip > Test.8k.GLPF.gz")

#Inputs to gl_parameter_finder:
#-bmatch - the binary output (from -bin_out) of GERMLINE; has one SH per row
#-bsid - the subject IDs output from GERMLINE
#-bmid - the marker IDs output from GERMLINE
#-ped-file - the path to the phased data; should be identical to the input -pedfile used in GERMLINE
#-window 50 - says to use a 50 SNP window for figuring moving average of IEs (MA)
#-cut-value .5 - says to trim the SH to the middlemost 50%: 25% from the left and 25% from the right are trimmed. This ensure that the remaining segment is IBD
#-reduced 500 8 - recommended paramers in real data; only use initial SHs that are at least 500 SNPs long and > 8cM. The outputed middlemost segments will typically be < 8cM (e.g., ~ 4+ cM)
#-output.type Error1 - this is the typical output format to be requested.
# | gzip > this pipes the standard out to gzip so the final output is a gzipped file.

###############





###############
#4)LOOK AT GL.PARAMTER.FINDER OUTPUT AND DETERMINE PIE & MA THRESHOLDS FOR FISHR

#We will read in different data than generated above - this is data phased with 8k individuals and is much higher quality
x <- read.table(gzfile("Test.8k.GLPF.gz"),header=TRUE)
nrow(x)
#Note, the file has 48908 SHs rather than 131098 outputed by GERMLINE. This is because many of the SHs from GERMLINE are not > 500 SNPs and > 8cM in length.

#The columns of the outputed gzip file are as follows:
#id1 - ID of the first person 
#id2 - ID of the second person who shares a SH with the first person
#marker_id1 - bp position for the first SNP of the middlemost section as defined by -cut-value (e.g., the middle 50% of the original SH if -cut-value is .50)
#marker_id2 - bp position for the last SNP of the middlemost section as defined by -cut-value
#snp_length - number of SNPs in the middlemost section
#cm_length - cM length of the middlemost section
#start.end - two values. first value is how many SNPs in the middlemost section started. So a value of 100 would mean that the original SH started at 1 (always) and the middlemost section started 100 SNPs into this. The second value is the final SNP of the middlemost section.
#pie - the proportion of IEs in this middlemost section
#ma_max - the maximum moving average (MA) of IEs in the middlemost section. The MA is averaged across the number of SNPs defined in -window.
#random_pie - the PIE for two random people at the same location (and length) as the middlemost section.
#random_ma_max - the MA for two random people at the same location (and length) as the middlemost section
#errors - where the IEs (separated by /) occurred in the middlemost section for the two original people in id1 and id2
#moving_averages - a vector (separated by /) of the MA values across all the SNPs in the middlemost section for the two original people in id1 and id2

x2 <- x[,1:11] #remove the moving average column

#histograms to visualize thresholds
op <- par(mfrow=c(2,2))
hist(x2$pie,xlim=c(0,.12),breaks=50,col='lightblue',main='histogram of PIE in truly IBD segments')
abline(v=.015,col='red')
hist(x2$ma_max,xlim=c(0,.3),breaks=50,col='lightgreen',main='histogram of max MA in truly IBD segments')
abline(v=.045,col='red')
hist(x2$random_pie,xlim=c(0,.12),breaks=50,col='darkblue',main='histogram of PIE in non-IBD segments')
abline(v=.015,col='red')
hist(x2$random_ma_max,xlim=c(0,.3),breaks=50,col='darkgreen',main='histogram of max MA in non-IBD segments')
abline(v=.045,col='red')
par(op)


#how many truly IBD segments would be dropped given cutoffs above?
x2$would.drop1 <- x2$ma_max > .045 | x2$pie > .015
summary(x2$would.drop1) #3957 of 48908
sum(x2$would.drop1)/nrow(x2) #3957/48908 = .081 is estimate of 1-sensitivity for this threshold for long SHs, so sensitivity ~ .92

#how many non-IBD segments would be retained given cutoffs above?
x2$would.keep1 <- x2$random_ma_max < .045 & x2$random_pie < .015
summary(x2$would.keep1) #95/48214, estimate of 1-specificity
sum(x2$would.keep1)/nrow(x2) #67/48908 = .001 is estimate of 1-specificity for this threshold for long SHs. So we would make very few wrong calls proportionately. Nevertheless, because the base rate of non-IBD is so much (~200 times) higher than IBD, the PPV can still be <<1, even with such high sensitivity and specificity values. So with these values, we might predict a PPV of ~.80 with a 200 folder higher rate of non-IBD vs. IBD.

#These seem like decent thresholds. Note that this method doesn't account for the increasing uncertainty that occurs at SH endpoints, where IEs begin to accumulate. In real data and for short IBD segments, the IEs ocurring at endpoints make up a greater and greater share of the total IBD segment length and increase the false negative and false positive rate.

###############












###############
#5) RUN GERMLINE2 FOR FINDING CANIDDIATE SEGMENTS FOR FISHR 

#Note again: the PED file must be phased for this to work

#We use the same PED file as above but now set the min_m to 1.5, half the length of our eventual desired cM threshold in FISHR. This allows some SHs broken up artificially by GERMLINE2 to be rejoined by FISHR.

#run GERMLINE2 to identify regions that are almost certainly IBD, at least in the middle
#If you get a library missing error, Navigate to the Germline2 folder and compile the program by issuing the make command.
system("./GERMLINE2 -pedfile Test.8k.ped -mapfile Test.8k.map -outfile Fin.8k -bin_out -err_hom 1 -err_het 1 -reduced -bits 60 -min_m 1.5 -w_extend -h_extend")

#OPTIMAL PARAAMETERS DISCOVERED FOR DETECTING 3+ cM SHs
#-pedfile - a PHASED pedfile. Note, you must use the
#-mapfile - a map file with cM distances in 3rd column
#-bin_out - a compressed output necessary for being read by gl.parameter.finder & FISHR
#-err_hom 1 - allow 1 mismatching homozygous markers
#-err_het 1 - allow 1 mismatching heterozygous markers
#-reduced - a flag telling GERMLINE2 to reduce the columns of the output; necessary for being read by gl.parameter.finder & FISHR
#-bits 60 - the # SNPs in each fixed window that GERMLINE2 uses for initial matches
#-min_m - minimum length in cM for match to be output; here 6
#-w_extend extend match beyond the "bits" window until the first mismatch occurs
#-h_extend - tells GERMLINE2 to use phase information as well as just opposite homozygosity in determining the SH length. Here, we DO use phase information to increase the accuracy of our initial calls.

#less Fin.8k.log
#you should have identified 2,343,583 IBD segments; some are false positives (which will hopefully be dropped by FISHR) and hopefully few enough are false negatives (because we can't recover those at this point). This is one reason why the thresholds above are a bit more lenient than what we'd use if we used GERMLINE2 alone.
###############





 




###############
#6) RUN FISHR

#FISHR terminal command
#If it gives a library missing error, compile the program by navigating into the folder Fishr and type make to invoke the makefile. Replace the new executable with the old one.

system("./FISHR -bmatch Fin.8k.bmatch -bsid Fin.8k.bsid -bmid Fin.8k.bmid -reduced 64 3 -ped-file Test.8k.ped -window 50 -empirical-ma-threshold .045 -gap 30 -emp-pie-threshold .015 -count.gap.errors TRUE -output-type finalOutput -log-file Fin.8kLOG | gzip -c > Fin.8k.gz")


#OPTIMAL PARAMETERS AND DESCRIPTIONS OF THEIR MEANINGS FOR CALLING 3+ CM SHS USING FISHR
#-bmatch/bsid/bmid - the files output from GERMLINE above
#-reduced 64 3 - tells FISHR that all SHs must be at least 64 SNPs (i.e., basically ignored) and final SHs must be > 3 cM in length
#-ped-file - location of original ped file; same used by GERMLINE
#-window 50 - the window used to calculate the moving average (MA) is 50 SNPs wide. The SNP in the middle of the window takes the average value of those 50 SNPs.
#-emperical-ma-threshold .045 - we break up SHs at the point where the MA value > .045. If the remaining SHs are < 3cM, the entire SH is dropped.
#-gap 30 - at the intial step, consolidate two SHs between the same two individuals if separated by fewer than 30 SNPs. If these are actually two separate IBD segments, they will often be broken up again at the MA step
#-emp-pie-threshold .015 - at the final step after the MA trimming, remove any SH that the proportion of IEs > .015 across the whole called segment.
#-count-gap-errors TRUE - says to count IEs in the gap whenever two SHs are joined (via the gap argument above). If this is FALSE (not recommended), then once joined, the MA step will not break up SHs at the gap junctures.
#-output.type finalOutput - the only output most users will ever need. finalOutput [default] (soon to be "Full") - Outputs the final called SHs. The columns of this file are pers1, pers2, bp.distance.start, bp.distance.end, no.of.snps.in.match, and cm.distance
#-log.file - name of log file.

#Note that FISHR writes to standard out, so needs to be piped to (e.g., gzip) and written to file.


#look at Fin.8kLOG.log (less Fin.8kLOG.log)
#you see the # consolidations (two SHs put together) was 31716, # removed due to initial length not being > 3 cM (after consolidation) ws ~1.79M, # removed due to the length following the MA trimming < 3 cM ~ 1.83M, # of those trimmed segments which still have a PIE > .015 being 739 and those were removed, and total number of outputed SHs > 3cM passing all thresholds is 483217.


###############











###############
#7) Look at FISHR output

ff <- read.table(gzfile("Fin.8k.gz"),header=FALSE,colClasses=c("character","character",rep("numeric",4)))
nrow(ff) #483217
names(ff) <- c('id1','id2','start','end','snps','cm')

#look at distribution of lengths
hist(ff$cm) #our genome is only 16 cM long, so some SHs stretch the entire genome.

#look at where they occur - plot the midpoints
ff$mdpt <- ff$start + (ff$end-ff$start)/2
hist(ff$mdpt,breaks=100,col='blue') #quite a bit of variability across the chromosome
###############























































