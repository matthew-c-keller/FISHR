import java.io.*;
import java.util.*;

public class FormatPed2 {
	
    public void work(String file){
		
	try{
			FileWriter FW = new FileWriter(file+".F");
			BufferedWriter out = new BufferedWriter(FW);
			
			try{
				BufferedReader reader1 = new BufferedReader(new FileReader(file));
				
				//add two 0 columns for parents
				//add unknown for sex
				//add 0 for phenotype
				
				//ONLY DONE IN FormatPed.java
				//Remove '_' in name
				//All 'A' are changed to a '1' and 
				//all 'C' are changed to a '2'
				//NO CHECKING if DIFFERENT CHANGES FOR DIFFERENT MAF
				
				String line="";
				int tab;
				String name="";
				
				while(reader1.ready()){
					
				    line = reader1.readLine();
					
				    //tab = line.indexOf("_");
					
				    //name = line.substring(0,tab);
					
					tab = line.indexOf(" ");
					//System.out.println(tab);
					name = line.substring(0,tab);
					line = line.substring(tab+1);
					
					out.write(name+" " +name+" 0 0 unknown 0 "+line);
					
					/*
					while(line.length()>4){
						if(line.charAt(0)=='A'){
							out.write(" 1");
						}else{
							out.write(" 2");
						}
						
						if(line.charAt(2)=='A'){
							out.write(" 1");
						}else{
							out.write(" 2");
						}
						
						line = line.substring(4);
						
					}
					
					if(line.charAt(0)=='A'){
						out.write(" 1");
					}else{
						out.write(" 2");
					}
					
					if(line.charAt(2)=='A'){
						out.write(" 1");
					}else{
						out.write(" 2");
					}
					*/

					out.newLine();					
				}
			
				reader1.close();
				
			}catch(IOException e){
				System.err.println("Error FileOpen " + e.getMessage());
			}
				
			out.close();
		}catch(IOException e){
			System.err.println("Error Filewriter " + e.getMessage());
		}
	}
	
	
	public static void main(String[] args){
		
		FormatPed2 FD = new FormatPed2();
		
		FD.work(args[0]);
	}

}
